# Customer Management Table

A production-quality data table built with React, TypeScript, and TanStack Table v8+ that displays customers with expandable nested order rows.

## Setup Instructions

```bash
# Install dependencies
npm install

# Run development server
npm start

# Build for production
npm run build
```

The application will be available at http://localhost:3000

## Features

- **Expandable Rows**: Each customer row can be expanded to show their orders
- **Selection**: Customers can be selected via checkboxes (orders are not selectable)
- **Global Search**: Search by Customer ID or Email
- **Status Filter**: Filter customers by Active/Inactive status
- **Sorting**: Sort by Last Updated (and ID column)
- **Pagination**: 25 customers per page (orders don't count toward page limit)

---

## Architecture Answers

### How you structured components

The application follows a simple, flat component structure:

```
src/
  types.ts              # Type definitions (Customer, Order)
  generateMockData.ts   # Mock data generator function
  CustomerTable.tsx     # Main table component with all logic
  App.tsx               # Root component
  App.css               # All styles
  index.tsx             # Entry point
```

**Why this structure?**

- **Single component approach**: Since the requirements are focused on one table with specific behaviors, everything is contained in `CustomerTable.tsx`. Splitting into smaller components (TableHeader, TableRow, Pagination) would add indirection without meaningful benefit for this scope.
- **Colocation**: Types, data generation, and the table component are separate files for clarity, but all table logic stays together where it's used.
- **No unnecessary abstractions**: No custom hooks, context providers, or utility modules were created because the logic is straightforward and doesn't need to be reused elsewhere.

### How customer-order relationships are modeled

```typescript
export type Order = {
  id: string;
  orderNumber: number;
  amount: number;
};

export type Customer = {
  id: string;
  email: string;
  status: "Active" | "Inactive";
  lastUpdated: number;
  orders: Order[];  // Nested array of orders
};
```

- **Parent-child via nesting**: Orders are embedded as an array property on each Customer
- **TanStack Table handles expansion**: The table's `getRowCanExpand` option checks if `orders.length > 0`
- **Manual order row rendering**: When a customer row is expanded, order rows are rendered manually in a `<>` fragment after the parent row. This keeps orders as display-only rows without being part of the table's data model.

This approach means:
- Pagination counts customers only (orders don't affect page size)
- Selection only applies to customers
- Filtering/sorting operates on customers, not orders

### How filtering, searching, and sorting are implemented

All filtering uses TanStack Table's built-in APIs:

**Global Search**
```typescript
globalFilterFn: (row, columnId, filterValue) => {
  const search = filterValue.toLowerCase();
  const customer = row.original;
  return (
    customer.id.toLowerCase().includes(search) ||
    customer.email.toLowerCase().includes(search)
  );
}
```
A custom filter function that checks both `id` and `email` fields.

**Status Filter**
```typescript
const filteredData = useMemo(() => {
  if (statusFilter === "All") return mockCustomers;
  return mockCustomers.filter((c) => c.status === statusFilter);
}, [statusFilter]);
```
Pre-filtering applied before passing data to the table. Simple array filter since it's a single field with known values.

**Sorting**
```typescript
getSortedRowModel: getSortedRowModel()
// Column definition:
{ accessorKey: "lastUpdated", sortingFn: "basic" }
```
TanStack Table's built-in sort model with the default "basic" sorting function for timestamps.

### Where you avoided over-engineering

1. **No state management library**: React's `useState` is sufficient for local table state
2. **No custom hooks**: `useTable`, `useSearch`, etc. would add abstraction without benefit
3. **No separated row components**: `CustomerRow` and `OrderRow` components would add props drilling for a single use case
4. **No column factory/builder pattern**: Column definitions are defined inline as a simple array
5. **No CSS-in-JS or styled-components**: Plain CSS is sufficient for this scope
6. **No memoization except where necessary**: Only `useMemo` for columns and filtered data where re-computation could be expensive
7. **Inline order row rendering**: Instead of adding orders to the table data model, they're rendered directly when expanded

### What would break first at 50k rows

1. **Initial render time**: Generating 50k customers with up to 5 orders each (potentially 250k order objects) would cause noticeable delay on page load. The `generateMockCustomers` function runs synchronously.

2. **Memory usage**: All 50k customer objects are held in memory. With React's virtual DOM, changing any table state would trigger diffing against a large virtual tree.

3. **Filtering performance**: The status pre-filter (`mockCustomers.filter()`) runs on every filter change. With 50k rows, this O(n) operation becomes noticeable.

4. **Global search**: The custom `globalFilterFn` runs on every row for each keystroke. Without debouncing, typing would feel sluggish.

5. **Selection state**: With 50k rows, selecting all would create 50k entries in the `rowSelection` object, and counting selected rows (`Object.keys(rowSelection).length`) becomes slower.

**Solutions for 50k rows:**
- **Virtualization**: Use `@tanstack/react-virtual` to only render visible rows
- **Server-side operations**: Move filtering, sorting, and pagination to the backend
- **Debounced search**: Add delay before applying search filter
- **Web Workers**: Generate mock data off the main thread
- **Indexed data structures**: Use Maps for O(1) lookups instead of array filters

---

## Tech Stack

- React 19
- TypeScript
- TanStack Table v8
- Create React App
