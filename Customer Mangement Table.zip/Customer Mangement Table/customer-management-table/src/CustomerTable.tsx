import React, { useMemo, useState } from "react";
import {
  useReactTable,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  getExpandedRowModel,
  flexRender,
  ColumnDef,
  SortingState,
  ExpandedState,
  RowSelectionState,
} from "@tanstack/react-table";
import { Customer, Order } from "./types";
import { generateMockCustomers } from "./generateMockData";


function formatRelativeTime(timestamp: number): string {
  const now = Date.now();
  const diff = now - timestamp;
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) return `${days} day${days > 1 ? "s" : ""} ago`;
  if (hours > 0) return `${hours} hour${hours > 1 ? "s" : ""} ago`;
  if (minutes > 0) return `${minutes} minute${minutes > 1 ? "s" : ""} ago`;
  return "Just now";
}

// Generate mock data 
const mockCustomers = generateMockCustomers(750);

export function CustomerTable() {
  const [sorting, setSorting] = useState<SortingState>([{ id: 'lastUpdated', desc: false }]);
  const [expanded, setExpanded] = useState<ExpandedState>({});
  const [rowSelection, setRowSelection] = useState<RowSelectionState>({});
  const [globalFilter, setGlobalFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState<"All" | "Active" | "Inactive">("All");

  // Filter data based on status
  const filteredData = useMemo(() => {
    if (statusFilter === "All") return mockCustomers;
    return mockCustomers.filter((c) => c.status === statusFilter);
  }, [statusFilter]);

  // Define columns
  const columns = useMemo<ColumnDef<Customer>[]>(
    () => [
      {
        id: "select",
        header: ({ table }) => (
          <input
            type="checkbox"
            checked={table.getIsAllPageRowsSelected()}
            onChange={table.getToggleAllPageRowsSelectedHandler()}
            aria-label="Select all customers"
          />
        ),
        cell: ({ row }) => (
          <input
            type="checkbox"
            checked={row.getIsSelected()}
            disabled={!row.getCanSelect()}
            onChange={row.getToggleSelectedHandler()}
            aria-label={`Select customer ${row.original.id}`}
          />
        ),
        enableSorting: false,
        size: 40,
      },
      {
        id: "expand",
        header: () => null,
        cell: ({ row }) => {
          if (row.original.orders.length === 0) {
            return <span style={{ width: 20, display: "inline-block" }} />;
          }
          return (
            <button
              onClick={() => row.toggleExpanded()}
              style={{
                cursor: "pointer",
                border: "none",
                background: "none",
                fontSize: "12px",
                padding: 0,
                width: 20,
              }}
              aria-label={row.getIsExpanded() ? "Collapse orders" : "Expand orders"}
            >
              {row.getIsExpanded() ? "▼" : "►"}
            </button>
          );
        },
        size: 30,
      },
      {
        accessorKey: "id",
        header: "ID",
        cell: (info) => info.getValue(),
        enableSorting: true,
      },
      {
        accessorKey: "email",
        header: "Email",
        cell: (info) => info.getValue(),
      },
      {
        accessorKey: "status",
        header: "Status",
        cell: (info) => {
          const status = info.getValue() as string;
          return (
            <span className={`status-badge status-${status.toLowerCase()}`}>
              {status}
            </span>
          );
        },
      },
      {
        accessorKey: "lastUpdated",
        header: "Last Updated",
        cell: (info) => formatRelativeTime(info.getValue() as number),
        sortingFn: "basic",
      },
    ],
    []
  );

  // Table instance
  const table = useReactTable({
    data: filteredData,
    columns,
    state: {
      sorting,
      expanded,
      rowSelection,
      globalFilter,
    },
    onSortingChange: setSorting,
    onExpandedChange: setExpanded,
    onRowSelectionChange: setRowSelection,
    onGlobalFilterChange: setGlobalFilter,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getExpandedRowModel: getExpandedRowModel(),
    getRowCanExpand: (row) => row.original.orders.length > 0,
    enableRowSelection: true,
    globalFilterFn: (row, columnId, filterValue) => {
      const search = filterValue.toLowerCase();
      const customer = row.original;
      return (
        customer.id.toLowerCase().includes(search) ||
        customer.email.toLowerCase().includes(search)
      );
    },
    initialState: {
      pagination: {
        pageSize: 25,
      },
    },
  });

  const selectedCount = Object.keys(rowSelection).length;

  // Render order rows
  const renderOrderRows = (orders: Order[]) => {
    return orders.map((order) => (
      <tr key={order.id} className="order-row">
        <td></td>
        <td></td>
        <td colSpan={4} className="order-cell">
          <span className="order-tree-line">└─</span>
          Order #{order.orderNumber} - Amount: ${order.amount.toFixed(2)}
        </td>
      </tr>
    ));
  };

  // Handle sort by change
  const handleSortChange = (value: string) => {
    if (value === 'lastUpdated-asc') {
      setSorting([{ id: 'lastUpdated', desc: false }]);
    } else if (value === 'lastUpdated-desc') {
      setSorting([{ id: 'lastUpdated', desc: true }]);
    }
  };

  const totalCustomers = table.getFilteredRowModel().rows.length;

  return (
    <div className="table-container">
      <div className="table-header">
        <div className="table-controls">
          <div className="search-box">
            <span className="search-icon">🔍</span>
            <input
              type="text"
              placeholder="Search..."
              value={globalFilter}
              onChange={(e) => setGlobalFilter(e.target.value)}
              aria-label="Search customers"
            />
          </div>
          <div className="filter-box">
            <label htmlFor="status-filter">Status:</label>
            <select
              id="status-filter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as "All" | "Active" | "Inactive")}
            >
              <option value="All">All</option>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
          <div className="sort-box">
            <label htmlFor="sort-by">Sort by:</label>
            <select
              id="sort-by"
              value={sorting[0]?.desc ? 'lastUpdated-desc' : 'lastUpdated-asc'}
              onChange={(e) => handleSortChange(e.target.value)}
            >
              <option value="lastUpdated-asc">Last Updated ↑</option>
              <option value="lastUpdated-desc">Last Updated ↓</option>
            </select>
          </div>
        </div>
      </div>
      
      <div className="selection-info-bar">
        {selectedCount > 0 && (
          <span className="selected-count">{selectedCount} customer{selectedCount > 1 ? "s" : ""} selected</span>
        )}
        {selectedCount > 0 && <span className="separator">|</span>}
        <span className="showing-info">
          Showing {table.getState().pagination.pageIndex * table.getState().pagination.pageSize + 1}-
          {Math.min(
            (table.getState().pagination.pageIndex + 1) * table.getState().pagination.pageSize,
            totalCustomers
          )} of {totalCustomers} Customers
        </span>
      </div>

      <table className="customer-table">
        <thead>
          {table.getHeaderGroups().map((headerGroup) => (
            <tr key={headerGroup.id}>
              {headerGroup.headers.map((header) => (
                <th
                  key={header.id}
                  style={{ width: header.getSize() }}
                  onClick={header.column.getCanSort() ? header.column.getToggleSortingHandler() : undefined}
                  className={header.column.getCanSort() ? "sortable" : ""}
                >
                  {header.isPlaceholder
                    ? null
                    : flexRender(header.column.columnDef.header, header.getContext())}
                  {header.column.id === 'lastUpdated' && header.column.getIsSorted() === "asc" && " ↑"}
                  {header.column.id === 'lastUpdated' && header.column.getIsSorted() === "desc" && " ↓"}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody>
          {table.getRowModel().rows.map((row) => (
            <React.Fragment key={row.id}>
              <tr className={`customer-row ${row.getIsSelected() ? 'selected-row' : ''}`}>
                {row.getVisibleCells().map((cell) => (
                  <td key={cell.id}>
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </td>
                ))}
              </tr>
              {row.getIsExpanded() && renderOrderRows(row.original.orders)}
            </React.Fragment>
          ))}
        </tbody>
      </table>

      <div className="table-footer">
        <div className="footer-left">
          <button 
            className="deactivate-btn"
            disabled={selectedCount === 0}
          >
            Deactivate Selected
          </button>
        </div>
        <div className="pagination-controls">
          <button
            onClick={() => table.previousPage()}
            disabled={!table.getCanPreviousPage()}
            className="pagination-arrow"
          >
            {"<"}
          </button>
          <div className="page-numbers">
            <button
              onClick={() => table.setPageIndex(0)}
              className={`page-number ${table.getState().pagination.pageIndex === 0 ? 'active' : ''}`}
            >
              1
            </button>
            <button
              onClick={() => table.setPageIndex(1)}
              className={`page-number ${table.getState().pagination.pageIndex === 1 ? 'active' : ''}`}
              disabled={table.getPageCount() < 2}
            >
              2
            </button>
            {table.getPageCount() > 3 && <span className="page-ellipsis">...</span>}
            {table.getPageCount() > 2 && (
              <button
                onClick={() => table.setPageIndex(table.getPageCount() - 1)}
                className={`page-number ${table.getState().pagination.pageIndex === table.getPageCount() - 1 ? 'active' : ''}`}
              >
                {table.getPageCount()}
              </button>
            )}
          </div>
          <button
            onClick={() => table.nextPage()}
            disabled={!table.getCanNextPage()}
            className="pagination-arrow"
          >
            {">"}
          </button>
        </div>
      </div>
      <div className="tanstack-footer">
        Powered by <a href="https://tanstack.com/table" target="_blank" rel="noopener noreferrer">TanStack Table</a>
      </div>
    </div>
  );
}
