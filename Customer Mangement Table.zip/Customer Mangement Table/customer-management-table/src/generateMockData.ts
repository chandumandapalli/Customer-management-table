import { Customer, Order } from "./types";

export function generateMockCustomers(count = 750): Customer[] {
  const customers: Customer[] = [];

  for (let i = 1; i <= count; i++) {
    const orderCount = Math.floor(Math.random() * 6); // 0 to 5 orders
    const orders: Order[] = [];

    for (let j = 1; j <= orderCount; j++) {
      orders.push({
        id: `order-${i}-${j}`,
        orderNumber: 100 + j,
        amount: Math.floor(Math.random() * 500) + 50,
      });
    }

    customers.push({
      id: `cust-${i}`,
      email: `customer${i}@example.com`,
      status: i % 3 === 0 ? "Inactive" : "Active",
      lastUpdated: Date.now() - Math.floor(Math.random() * 1000 * 60 * 60 * 24 * 30), // Last 30 days
      orders,
    });
  }

  return customers;
}
